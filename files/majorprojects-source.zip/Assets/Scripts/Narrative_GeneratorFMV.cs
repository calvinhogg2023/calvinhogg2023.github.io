using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Narrative_GeneratorFMV : MonoBehaviour
{
    Animator m_Transitions;
    GameObject Player;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(GeneratorFMV());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public IEnumerator GeneratorFMV()
    {
        float timeElapsed = 0;
        float lerpDuration = 8f;

        while (timeElapsed < lerpDuration)
        {
            timeElapsed += Time.deltaTime;
            yield return null;
        }
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("bossRoom", LoadSceneMode.Single);
    }
}
