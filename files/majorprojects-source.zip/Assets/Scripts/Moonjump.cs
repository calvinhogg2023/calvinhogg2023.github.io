﻿using UnityEngine;
using UnityEngine.Events;

public class Moonjump : MonoBehaviour
{
    [Tooltip("The strength with which the jetpack pushes the player up")]
    public float JetpackAcceleration = 4f;

    [Range(0f, 2f)]
    [Tooltip("This will affect how much using the jetpack will cancel the gravity value, to start going up faster. 0 is not at all, 1 is instant")]
    public float JetpackDownwardVelocityCancelingFactor = 1.25f;

    PlayerCharacterController m_PlayerCharacterController;
    PlayerInputHandler m_InputHandler;

    void Start()
    {
        m_PlayerCharacterController = GetComponent<PlayerCharacterController>();
        m_InputHandler = GetComponent<PlayerInputHandler>();
    }

    void Update()
    {
        bool MoonjumpInUse = m_InputHandler.GetJumpInputHeld();

        if (MoonjumpInUse && GlobalVariables.instance.stat_moonjump == true)
        {
            float totalAcceleration = JetpackAcceleration;

            // cancel out gravity
            totalAcceleration += m_PlayerCharacterController.Gravity;

            if (m_PlayerCharacterController.CharacterVelocity.y < 0f)
            {
                // handle making moonjump compensate for character's downward velocity with bonus acceleration
                totalAcceleration += ((-m_PlayerCharacterController.CharacterVelocity.y / Time.deltaTime) *
                                        JetpackDownwardVelocityCancelingFactor);
            }

            // apply the acceleration to character's velocity
            m_PlayerCharacterController.CharacterVelocity += Vector3.up * totalAcceleration * Time.deltaTime;

        }
    }
}
