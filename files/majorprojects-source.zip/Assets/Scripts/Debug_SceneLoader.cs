using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Debug_SceneLoader : MonoBehaviour
{
    int selectedScene = 1;
    string selectedSceneName;
    public bool sceneExists;
    private AudioSource audioSource;
    [SerializeField] private AudioClip navigate;
    [SerializeField] private AudioClip confirm;
    [SerializeField] private AudioClip error;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("left"))
        {
            if (selectedScene <= 1)
            {
                //Do nothing
            }
            else
            {
                audioSource = GetComponent<AudioSource>();
                audioSource.clip = navigate;
                audioSource.Play();
                selectedScene = selectedScene - 1;
            }
        }
        else if (Input.GetKeyDown("right"))
        {
            if (selectedScene >= 7)
            {
                //Do nothing
            }
            else
            {
                audioSource = GetComponent<AudioSource>();
                audioSource.clip = navigate;
                audioSource.Play();
                selectedScene = selectedScene + 1;
            }
        }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (sceneExists == true)
            {
                audioSource = GetComponent<AudioSource>();
                audioSource.clip = confirm;
                audioSource.Play();
                StartCoroutine(WaitBeforeSceneLoad());
            }
            else
            {
                audioSource = GetComponent<AudioSource>();
                audioSource.clip = error;
                audioSource.Play();
            }
        }

        if (selectedScene == 1)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "testMap";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("testMap");
        }
        else if (selectedScene == 2)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "courtyard";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("courtyard");
        }
        else if (selectedScene == 3)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "lobby";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("lobby");
        }
        else if (selectedScene == 4)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "cyberthugCore";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("cyberthugCore");
        }
        else if (selectedScene == 5)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "gallery";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("gallery");
        }
        else if (selectedScene == 6)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "dungeon";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("dungeon");
        }
        else if (selectedScene == 7)
        {
            sceneExists = true;
            GetComponent<TMPro.TextMeshProUGUI>().color = new Color(1, 1, 1);

            selectedSceneName = "bossRoom";
            GetComponent<TMPro.TextMeshProUGUI>().text = ("bossRoom");
        }
    }

    IEnumerator WaitBeforeSceneLoad()
    {
        yield return new WaitForSeconds(0.5f);
        SceneManager.LoadScene(selectedSceneName, LoadSceneMode.Single);
    }
}
