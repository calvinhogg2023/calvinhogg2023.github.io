﻿using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(AudioSource))]
public class Jetpack : MonoBehaviour
{
    [Header("References")] [Tooltip("Audio source for jetpack sfx")]
    public AudioSource AudioSource;

    [Tooltip("Particles for jetpack vfx")] public ParticleSystem[] JetpackVfx;

    [Tooltip("The strength with which the jetpack pushes the player up")]
    public float JetpackAcceleration = 7f;

    [Range(0f, 1f)]
    [Tooltip(
        "This will affect how much using the jetpack will cancel the gravity value, to start going up faster. 0 is not at all, 1 is instant")]
    public float JetpackDownwardVelocityCancelingFactor = 1f;

    [Header("Durations")] [Tooltip("Time it takes to consume all the jetpack fuel")]
    public float ConsumeDuration = 2f;

    [Tooltip("Time it takes to completely refill the jetpack while on the ground")]
    public float RefillDurationGrounded = 2f;

    //public float RefillDurationInTheAir = 2f;

    [Tooltip("Delay after last use before starting to refill")]
    public float RefillDelay = 0f;

    [Header("Audio")] [Tooltip("Sound played when using the jetpack")]
    public AudioClip JetpackSfx;

    bool m_CanUseJetpack;
    PlayerCharacterController m_PlayerCharacterController;
    PlayerInputHandler m_InputHandler;
    float m_LastTimeOfUse;

    // stored ratio for jetpack resource (1 is full, 0 is empty)
    public float CurrentFillRatio { get; private set; }

    public bool IsPlayergrounded() => m_PlayerCharacterController.IsGrounded;

    public UnityAction<bool> OnUnlockJetpack;

    void Start()
    {
        GlobalVariables.instance.JetpackUnlocked = GlobalVariables.instance.JetpackUnlockedAtStart;

        m_PlayerCharacterController = GetComponent<PlayerCharacterController>();
        m_InputHandler = GetComponent<PlayerInputHandler>();
        CurrentFillRatio = 1f;

        AudioSource.clip = JetpackSfx;
        AudioSource.loop = true;
    }

    void Update()
    {
        // jetpack can only be used if not grounded and jump has been pressed again once in-air
        if (IsPlayergrounded())
        {
            m_CanUseJetpack = false;
        }
        else if (!m_PlayerCharacterController.HasJumpedThisFrame && m_InputHandler.GetJumpInputDown())
        {
            if (GlobalVariables.instance.stat_moonjump == false)
            {
                m_CanUseJetpack = true;
            } else
            {
                m_CanUseJetpack = false;
            }
        }

        // jetpack usage
        bool jetpackIsInUse = m_CanUseJetpack && GlobalVariables.instance.JetpackUnlocked && CurrentFillRatio > 0f &&
                                m_InputHandler.GetJumpInputHeld();
        if (jetpackIsInUse)
        {
            // store the last time of use for refill delay
            m_LastTimeOfUse = Time.time;

            float totalAcceleration = JetpackAcceleration;

            // cancel out gravity
            totalAcceleration += m_PlayerCharacterController.Gravity;

            if (m_PlayerCharacterController.CharacterVelocity.y < 0f)
            {
                // handle making the jetpack compensate for character's downward velocity with bonus acceleration
                totalAcceleration += ((-m_PlayerCharacterController.CharacterVelocity.y / Time.deltaTime) *
                                        JetpackDownwardVelocityCancelingFactor);
            }

            // apply the acceleration to character's velocity
            m_PlayerCharacterController.CharacterVelocity += Vector3.up * totalAcceleration * Time.deltaTime;

            // consume fuel
            CurrentFillRatio = CurrentFillRatio - (Time.deltaTime / ConsumeDuration);

            for (int i = 0; i < JetpackVfx.Length; i++)
            {
                var emissionModulesVfx = JetpackVfx[i].emission;
                emissionModulesVfx.enabled = true;
            }

            if (!AudioSource.isPlaying)
                AudioSource.Play();
        }
        else
        {
            // refill the meter over time
            if (GlobalVariables.instance.JetpackUnlocked && Time.time - m_LastTimeOfUse >= RefillDelay)
            {
                if (IsPlayergrounded())
                {
                    float refillRate = 0.4f;
                    CurrentFillRatio = CurrentFillRatio + Time.deltaTime * refillRate;
                }
            }

            for (int i = 0; i < JetpackVfx.Length; i++)
            {
                var emissionModulesVfx = JetpackVfx[i].emission;
                emissionModulesVfx.enabled = false;
            }

            // keeps the ratio between 0 and 1
            CurrentFillRatio = Mathf.Clamp01(CurrentFillRatio);

            if (AudioSource.isPlaying)
                AudioSource.Stop();
        }
    }

    public bool TryUnlock()
    {
        if (GlobalVariables.instance.JetpackUnlocked)
            return false;

        OnUnlockJetpack.Invoke(true);
        GlobalVariables.instance.JetpackUnlocked = true;
        m_LastTimeOfUse = Time.time;
        return true;
    }
}
