﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class InGameMenuManager : MonoBehaviour
{
    [Tooltip("Root GameObject of the menu used to toggle its activation")]
    public GameObject MenuRoot;

    [Tooltip("Master volume when menu is open")] [Range(0.001f, 1f)]
    public float VolumeWhenMenuOpen = 0.5f;

    PlayerInputHandler m_PlayerInputsHandler;
    Health m_PlayerHealth;
    GameObject ToggleMusic;
    GameObject GameManager;

    void Start()
    {
        m_PlayerInputsHandler = FindObjectOfType<PlayerInputHandler>();
        m_PlayerHealth = m_PlayerInputsHandler.GetComponent<Health>();

        MenuRoot.SetActive(false);
     }

    void Update()
    {

        // Lock cursor when clicking outside of menu
        if (!MenuRoot.activeSelf && Input.GetMouseButtonDown(0))
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        if (Input.GetButtonDown(GameConstants.k_ButtonNamePauseMenu)
            || (MenuRoot.activeSelf && Input.GetButtonDown(GameConstants.k_ButtonNameCancel)))
        {

            SetPauseMenuActivation(!MenuRoot.activeSelf);

        }

        if (Input.GetAxisRaw(GameConstants.k_AxisNameVertical) != 0)
        {
            if (EventSystem.current.currentSelectedGameObject == null)
            {
                EventSystem.current.SetSelectedGameObject(null);
            }
        }
    }

    public void ClosePauseMenu()
    {
        SetPauseMenuActivation(false);
    }

    public void ReturnToMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("titleScreen", LoadSceneMode.Single);
    }

    void SetPauseMenuActivation(bool active)
    {
        MenuRoot.SetActive(active);

        if (MenuRoot.activeSelf)
        {
            //ppvPaused.Play("PPV Paused_enable");
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            Time.timeScale = 0f;
            GlobalVariables.instance.gamePaused = true;
            EventSystem.current.SetSelectedGameObject(null);
        }
        else
        {
            //ppvPaused.Play("PPV Paused_disable");
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            Time.timeScale = 1f;
            GlobalVariables.instance.gamePaused = false;
        }

    }

    public void ChangeValueToTrue()
    {
        ToggleMusic.GetComponent<Toggle>().isOn = true;
        GameManager.GetComponent<AudioSource>().enabled = true;
    }

    public void ChangeValueToFalse()
    {
        ToggleMusic.GetComponent<Toggle>().isOn = false;
        GameManager.GetComponent<AudioSource>().enabled = false;
    }
}
