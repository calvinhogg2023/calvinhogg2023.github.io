using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Debug_Hotkeys : MonoBehaviour
{
    GameObject player;
    AudioSource BackgroundMusic;

    void Start()
    {
        player = GameObject.Find("Player");
        BackgroundMusic = GameObject.Find("GameManager_BGM").GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetKey("p"))
        {
            if (Input.GetKeyDown("1"))
            {
                Screen.fullScreen = !Screen.fullScreen;
            }

            else if (Input.GetKeyDown("2"))
            {
                if (QualitySettings.vSyncCount == 0)
                {
                    QualitySettings.vSyncCount = 1;
                    PlayerPrefs.SetInt("Pref_Vsync", 1);
                    PlayerPrefs.Save();
                }
                else
                {
                    QualitySettings.vSyncCount = 0;
                    PlayerPrefs.SetInt("Pref_Vsync", 0);
                    PlayerPrefs.Save();
                }
            }

            else if (Input.GetKeyDown("3"))
            {
                if (GlobalVariables.instance.stat_moonjump == false)
                {
                    GlobalVariables.instance.stat_moonjump = true;
                    PlayerPrefs.SetInt("Pref_Moonjump", 1);
                    PlayerPrefs.Save();
                }
                else
                {
                    GlobalVariables.instance.stat_moonjump = false;
                    PlayerPrefs.SetInt("Pref_Moonjump", 0);
                    PlayerPrefs.Save();
                }
            }

            else if (Input.GetKeyDown("4"))
            {
                if (GlobalVariables.instance.stat_backgroundMusic == false)
                {
                    GlobalVariables.instance.stat_backgroundMusic = true;
                    BackgroundMusic.mute = false;
                    PlayerPrefs.SetInt("Pref_BackgroundMusic", 1);
                    PlayerPrefs.Save();
                }
                else
                {
                    GlobalVariables.instance.stat_backgroundMusic = false;
                    BackgroundMusic.mute = true;
                    PlayerPrefs.SetInt("Pref_BackgroundMusic", 0);
                    PlayerPrefs.Save();
                }
            }

            else if (Input.GetKeyDown("0"))
            {
                SceneManager.LoadScene("titleScreen", LoadSceneMode.Single);
            }
        }
    }
}
