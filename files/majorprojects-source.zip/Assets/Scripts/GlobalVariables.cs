using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalVariables : MonoBehaviour
{
    public static GlobalVariables instance = null;
    public bool JetpackUnlocked;
    public bool JetpackUnlockedAtStart;
    public int DeathTransitionPlayed = 0;

    public bool gamePaused;

    // debug features
    public bool stat_moonjump;
    public bool stat_backgroundMusic;
    public bool stat_soundEffects;

    public bool raycastActive;
    public string raycastObject;

    public int courtyardExitPoint;

    void Awake()
    {
        instance = this;
    }

    //this script should remain empty. its a way to store variables in a globally available manner
}
