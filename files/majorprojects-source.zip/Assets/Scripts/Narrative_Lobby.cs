using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Narrative_Lobby : MonoBehaviour
{
    Animator m_Transitions;
    GameObject Player;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        m_Transitions = GameObject.Find("Transitions").GetComponent<Animator>();
        m_Transitions.Play("transitions_sceneEnter");
        Player = GameObject.Find("Player");
        audioSource = gameObject.GetComponentInParent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
