using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Narrative_PlumLab : MonoBehaviour
{
    Animator m_Transitions;
    GameObject Player;
    AudioSource audioSource;

    public AudioClip doorLockedSFX;
    public GameObject raycastObject;

    // Start is called before the first frame update
    void Start()
    {
        m_Transitions = GameObject.Find("Transitions").GetComponent<Animator>();
        m_Transitions.Play("transitions_sceneEnter");
        Player = GameObject.Find("Player");
        audioSource = gameObject.GetComponentInParent<AudioSource>();
    }

    /*

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && RootVariables.instance.raycastActive == true)
        {
            audioSource.PlayOneShot(doorLockedSFX);
            Debug.Log(RootVariables.instance.raycastObject);
            StartCoroutine(OpenMaintenanceDoor());
        }
    }
    
    public IEnumerator OpenMaintenanceDoor()
    {
        raycastObject = GameObject.Find(RootVariables.instance.raycastObject);
        raycastObject.tag = "Untagged";
        Quaternion startRotation = raycastObject.transform.rotation;
        float endYRot = -120f;
        float duration = 1f;
        float time = 0;

        while (time < 1f)
        {
            time = Mathf.Min(1f, time + Time.deltaTime / duration);
            Vector3 newEulerOffset = Vector3.up * (endYRot * time);
            // global z rotation
            raycastObject.transform.rotation = Quaternion.Euler(newEulerOffset) * startRotation;
            // local z rotation
            // transform.rotation = startRotation * Quaternion.Euler(newEulerOffset);
            yield return null;
        }
    }
    */
}
