using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Narrative_Outside : MonoBehaviour
{
    Animator m_Transitions;
    GameObject Player;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        int Data_OutsideCleared = PlayerPrefs.GetInt("Data_OutsideCleared");
        

        m_Transitions = GameObject.Find("Transitions").GetComponent<Animator>();
        Player = GameObject.Find("Player");
        audioSource = gameObject.GetComponentInParent<AudioSource>();

        if (Data_OutsideCleared == 1)
        {
            Player.transform.position = new Vector3(0, 1.65f, 19.87f);
            Player.transform.eulerAngles = new Vector3(0, 180, 0);
        }
        else
        {
            //nothing
        }

        m_Transitions.Play("transitions_sceneStart");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
