﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using TMPro;

public class Health : MonoBehaviour
{
    public int MaxHealth;
    public bool Invincible;
    public AudioSource AudioSource;
    public AudioClip TakeDamageSFX;

    PlayerInputHandler m_InputHandler;
    PlayerCharacterController m_PlayerCharacterController;
    Transitions m_Transitions;
    public Image _HealthBar;
    Animator DamageGUI;
    Animator DeathGUI;

    public UnityAction<float, GameObject> OnDamaged;
    public UnityAction<float> OnHealed;
    public float CurrentHealth { get; set; }
    public bool CanPickup() => CurrentHealth < MaxHealth;
    public float GetRatio() => CurrentHealth / MaxHealth;
    bool m_IsDead;

    void Start()
    {
        MaxHealth = 16;
        DamageGUI = GameObject.Find("DamageGUI").GetComponent<Animator>();
        DeathGUI = GameObject.Find("DeathGUI").GetComponent<Animator>();
        _HealthBar = GameObject.Find("HealthFillImage").GetComponent<Image>();
        m_Transitions = GameObject.Find("Transitions").GetComponent<Transitions>();
        m_InputHandler = GetComponent<PlayerInputHandler>();
        m_PlayerCharacterController = GetComponent<PlayerCharacterController>();
        CurrentHealth = MaxHealth;
    }

    void Update()
    {
        // Adjust the number of hearts visible based on health level
        switch (CurrentHealth)
        {
            case 16:
                _HealthBar.fillAmount = 1f;
                break;
            case 15:
                _HealthBar.fillAmount = 0.933f;
                break;
            case 14:
                _HealthBar.fillAmount = 0.87f;
                break;
            case 13:
                _HealthBar.fillAmount = 0.813f;
                break;
            case 12:
                _HealthBar.fillAmount = 0.75f;
                break;
            case 11:
                _HealthBar.fillAmount = 0.688f;
                break;
            case 10:
                _HealthBar.fillAmount = 0.63f;
                break;
            case 9:
                _HealthBar.fillAmount = 0.563f;
                break;
            case 8:
                _HealthBar.fillAmount = 0.5f;
                break;
            case 7:
                _HealthBar.fillAmount = 0.44f;
                break;
            case 6:
                _HealthBar.fillAmount = 0.38f;
                break;
            case 5:
                _HealthBar.fillAmount = 0.318f;
                break;
            case 4:
                _HealthBar.fillAmount = 0.25f;
                break;
            case 3:
                _HealthBar.fillAmount = 0.193f;
                break;
            case 2:
                _HealthBar.fillAmount = 0.133f;
                break;
            case 1:
                _HealthBar.fillAmount = 0.07f;
                break;
            case 0:
                _HealthBar.fillAmount = 0f;
                break;
            default:
                _HealthBar.fillAmount = 0f;
                break;
        }
        if (CurrentHealth == 0)
        {
            Kill();
        }
    }

    public void Heal(float healAmount)
    {
        float healthBefore = CurrentHealth;
        CurrentHealth += healAmount;
        CurrentHealth = Mathf.Clamp(CurrentHealth, 0f, MaxHealth);

        // call OnHeal action
        float trueHealAmount = CurrentHealth - healthBefore;
        if (trueHealAmount > 0f)
        {
            OnHealed?.Invoke(trueHealAmount);
        }
    }

    public void TakeDamage(float damage, GameObject damageSource)
    {
        if (Invincible)
            return;

        DamageGUI.Play("damage");
        float healthBefore = CurrentHealth;
        CurrentHealth -= damage;
        CurrentHealth = Mathf.Clamp(CurrentHealth, 0f, MaxHealth);

        // call OnDamage action
        float trueDamageAmount = healthBefore - CurrentHealth;
        if (trueDamageAmount > 0f)
        {
            OnDamaged?.Invoke(trueDamageAmount, damageSource);
        }
    }

    public void Kill()
    {
        DeathGUI.Play("death");
        StartCoroutine(DeathTransition());
    }

    public IEnumerator DeathTransition()
    {
        //float startVolume = Music.volume;
        //float endVolume = 0;
        float timeElapsed = 0;
        float lerpDuration = 1.5f;

        while (timeElapsed < lerpDuration)
        {
            timeElapsed += Time.deltaTime;
            //Music.volume = Mathf.Lerp(startVolume, endVolume, timeElapsed / lerpDuration);
            yield return null;
        }
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("titleScreen", LoadSceneMode.Single);
    }
}
