using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Transitions : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip sceneStart;
    public AudioClip sceneEnter;
    public AudioClip sceneExit;
    public AudioClip death;
    Animator animator;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SceneExit()
    {
        audioSource.clip = sceneExit;
        audioSource.Play();
        animator = this.GetComponent<Animator>();
        animator.Play("transitions_sceneExit");
    }

    public void Damage()
    {
        animator = this.GetComponent<Animator>();
        animator.Play("transitions_damage");
    }

    public void Death()
    {
        audioSource.clip = death;
        audioSource.Play();
        animator = this.GetComponent<Animator>();
        animator.Play("transitions_death");
        GlobalVariables.instance.DeathTransitionPlayed = 1;
    }
}
