using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class PickupsAndTriggers : MonoBehaviour
{
    AudioSource SFX;
    AudioSource Music;
    GameObject JetpackPickup;
    GameObject Trigger1;
    GameObject Trigger2;

    public AudioClip audioClip_pickup;
    public AudioClip audioClip_trigger;

    public GameObject doorLeft;
    public GameObject doorRight;
    private Animator dylan;

    Transitions m_Transitions;

    void Awake()
    {
        SFX = GameObject.Find("SFX").GetComponent<AudioSource>();
    }

    void Start()
    {
        m_Transitions = GameObject.Find("Transitions").GetComponent<Transitions>();
        JetpackPickup = GameObject.Find("jetpack");
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "trigger_dylan")
        {
            dylan = GameObject.Find("Dylan").GetComponent<Animator>();
            dylan.Play("dylanCon_triggered");
        }
        if (other.gameObject.name == "jetpack")
        {
            SFX.clip = audioClip_pickup;
            SFX.Play(0);
            GlobalVariables.instance.JetpackUnlocked = true;
            Destroy(JetpackPickup);
        }
        if (other.gameObject.name == "warp_lobby")
        {
            GlobalVariables.instance.courtyardExitPoint = 2;
        }
    }

    public IEnumerator SceneTransition(string scene)
    {
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene(scene, LoadSceneMode.Single);
    }
}
