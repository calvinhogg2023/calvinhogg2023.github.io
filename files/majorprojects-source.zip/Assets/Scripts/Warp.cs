using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Warp : MonoBehaviour
{
    public string SceneToWarpTo;
    private Scene scene;
    private string currentScene;

    void Start()
    {
        scene = SceneManager.GetActiveScene();
        currentScene = scene.name;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player")
        {
            StartCoroutine(loadScene(other, currentScene, SceneToWarpTo));
        }
    }

    IEnumerator loadScene(Collider other, string currentScene, string SceneToWarpTo)
    {
        //SceneManager.LoadScene(SceneToWarpTo);
        yield return SceneManager.LoadSceneAsync(SceneToWarpTo);
        other.transform.position = GameObject.Find("spawnpoint1").transform.position;
    }
}
