﻿using UnityEngine;
using UnityEngine.UI;

public class JetpackCounter : MonoBehaviour
{
    [Tooltip("Image component representing jetpack fuel")]
    public Image JetpackFillImage;

    [Tooltip("Canvas group that contains the whole UI for the jetack")]
    public CanvasGroup MainCanvasGroup;

    Jetpack m_Jetpack;

    void Awake()
    {
        m_Jetpack = FindObjectOfType<Jetpack>();
    }

    void Update()
    {
        MainCanvasGroup.gameObject.SetActive(GlobalVariables.instance.JetpackUnlocked);

        if (GlobalVariables.instance.JetpackUnlocked)
        {
            JetpackFillImage.fillAmount = m_Jetpack.CurrentFillRatio;
        }
    }
}
