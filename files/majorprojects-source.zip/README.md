![proposal.png](proposal.png)
## Introduction
Phoenix Nest is a game I'm working on for the first semester of Major Projects 2022.

## Versioning standards
Apart from the early December 2021 builds, every build adheres to a standard when it comes to their name.

The format is as follows: **vMAJOR.MINOR-STAGE-YYYY-MM-DD**

The build **v1.0-alpha-2022-03-04**, for instance, is working toward the first stable release, although it's still unstable. It was built on March 4th, 2022 and features basic FPS gameplay and a few basic scenes.

### Stages

- **Alpha**: Development focuses on adding new content, which may be rough around the edges. Some assets may be placeholders and are subject to change.

- **Beta**: Development focuses on refining new content and fixing bugs. Performance optimizations are a big focus here.

- **Candidate**: Version is ready for release unless significant bugs are found. Extensive playtesting and gathering feedback will typically happen during this stage.

- **Release**: Build is ready to be distributed.

## Timeline
![timeline.png](timeline.png)

### 2021

- **1 December:** Development on Phoenix Nest began.

### 2022

- **7 January:** Project is rebuilt from scratch with FPS gameplay.

- **28 February:** Start of school semester. Phoenix Nest is repurposed for Major Projects.

- **April:** Phoenix Nest moves to beta stage.

- **May:** Phoenix Nest moves to candidate stage for a week.

- **1 June 2022:** Development on Nestos River begins.

- **14 June 2022:** Virtual exhibition of Major Projects.
